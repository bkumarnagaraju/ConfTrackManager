package com.thoughtWorks.conferenceTrackManagement;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Conference Manager
 * @author Bharath
 *
 */
public class ConferenceTrackManager {
    public List<List<TechTalk>> scheduleConference(String fileName)
            throws Exception {
        List<String> techTalkList = getTalkListFromFile(fileName);
        return scheduleConference(techTalkList);
    }

    public List<List<TechTalk>> scheduleConference(List<String> techTalkList)
            throws Exception {
        List<TechTalk> talksList = validateAndCreateTechTalks(techTalkList);
        return getScheduleConferenceTrack(talksList);
    }

    public List<String> getTalkListFromFile(String fileName)
            throws InvalidTechTalkException {
        List<String> techTalkList = new ArrayList<String>();
        try {
            // Open the file.
            FileInputStream fstream = new FileInputStream(fileName);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine = br.readLine();
            // Read File Line By Line
            while (strLine != null) {
                techTalkList.add(strLine);
                strLine = br.readLine();
            }
            // Close the input stream
            in.close();
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
        return techTalkList;
    }

    //Validate list of tech talks
    private List<TechTalk> validateAndCreateTechTalks(List<String> techTalkList)
            throws Exception {

        if (techTalkList == null)
            throw new InvalidTechTalkException("Tech Talk List is empty!!");

        List<TechTalk> validTalksList = new ArrayList<TechTalk>();
        int talkCount = -1;
        String minutesSuffix = "min";
        String lightningSuffix = "lightning";

        for (String techTalk : techTalkList) {
            int lastSpaceIndex = techTalk.lastIndexOf(" ");
            // if tech techTalk does not have any space, means either title or time is missing.
            if (lastSpaceIndex == -1)
                throw new InvalidTechTalkException("Not a valid techTalk, " + techTalk
                        + ". Tech Talk time must be specify.");

            String name = techTalk.substring(0, lastSpaceIndex);
            String timeStr = techTalk.substring(lastSpaceIndex + 1);
            // If title is missing or blank.
            if (name == null || "".equals(name.trim()))
                throw new InvalidTechTalkException("Invalid techTalk name, " + techTalk);
            // If time is not ended with min or lightning.
            else if (!timeStr.endsWith(minutesSuffix)
                    && !timeStr.endsWith(lightningSuffix))
                throw new InvalidTechTalkException("Invalid techTalk time, " + techTalk
                        + ". Time must be in min or in lightning");

            talkCount++;
            int time = 0;
            // Parse time from the time string .
            try {
                if (timeStr.endsWith(minutesSuffix)) {
                    time = Integer.parseInt(timeStr.substring(0,
                            timeStr.indexOf(minutesSuffix)));
                } else if (timeStr.endsWith(lightningSuffix)) {
                    String lightningTime = timeStr.substring(0,
                            timeStr.indexOf(lightningSuffix));
                    if ("".equals(lightningTime))
                        time = 5;
                    else
                        time = Integer.parseInt(lightningTime) * 5;
                }
            } catch (NumberFormatException nfe) {
                throw new InvalidTechTalkException("Unbale to parse time "
                        + timeStr + " for techTalk " + techTalk);
            }
            // Add techTalk to the valid techTalk List.
            validTalksList.add(new TechTalk(techTalk, name, time));
        }

        return validTalksList;
    }

    private List<List<TechTalk>> getScheduleConferenceTrack(List<TechTalk> talksList)
            throws Exception {
        // Find the total possible days.
        int perDayMinTime = 6 * 60;
        int totalTalksTime = getTotalTalksTime(talksList);
        int totalPossibleDays = totalTalksTime / perDayMinTime;

        // Sort the techTalkList.
        List<TechTalk> talksListForOperation = new ArrayList<TechTalk>();
        talksListForOperation.addAll(talksList);
        //TechTalk implements comparable see file for natural ordering
        Collections.sort(talksListForOperation);

        // Find possible combinations for the morning session.
        List<List<TechTalk>> combForMornSessions = findPossibleCombSession(
                talksListForOperation, totalPossibleDays, true);

        // Remove all the scheduled talks for morning session
        for (List<TechTalk> techTalkList : combForMornSessions) {
            talksListForOperation.removeAll(techTalkList);
        }

        // Find possible combinations for the evening session.
        List<List<TechTalk>> combForEveSessions = findPossibleCombSession(
                talksListForOperation, totalPossibleDays, false);

        // Remove all the scheduled talks for evening session
        for (List<TechTalk> techTalkList : combForEveSessions) {
            talksListForOperation.removeAll(techTalkList);
        }

        int maxSessionTimeLimit = 240;
        if (!talksListForOperation.isEmpty()) {
            List<TechTalk> scheduledTalkList = new ArrayList<TechTalk>();
            for (List<TechTalk> techTalkList : combForEveSessions) {
                int totalTime = getTotalTalksTime(techTalkList);

                for (TechTalk techTalk : talksListForOperation) {
                    int talkTime = techTalk.getTimeDuration();

                    if (talkTime + totalTime <= maxSessionTimeLimit) {
                        techTalkList.add(techTalk);
                        techTalk.setScheduled(true);
                        scheduledTalkList.add(techTalk);
                    }
                }

                talksListForOperation.removeAll(scheduledTalkList);
                if (talksListForOperation.isEmpty())
                    break;
            }
        }

        // If operation list is still not empty, conf cannot be scheduled
        if (!talksListForOperation.isEmpty()) {
            throw new Exception("Unable to schedule all task for conferencing.");
        }

        // Schedule the day event from morning session and evening session.
        return getScheduledTalksList(combForMornSessions, combForEveSessions);
    }

    private List<List<TechTalk>> findPossibleCombSession(
            List<TechTalk> talksListForOperation, int totalPossibleDays,
            boolean morningSession) {
        int minSessionTimeLimit = 180;
        int maxSessionTimeLimit = 240;

        if (morningSession){
            maxSessionTimeLimit = minSessionTimeLimit;
        }
        int techTalkListSize = talksListForOperation.size();
        List<List<TechTalk>> possibleCombinationsOfTalks = new ArrayList<List<TechTalk>>();
        int possibleCombinationCount = 0;

        // Loop to get combination for total possible days.
        // Check one by one from each techTalk to get possible combination.
        for (int count = 0; count < techTalkListSize; count++) {
            int startPoint = count;
            int totalTime = 0;
            List<TechTalk> possibleCombinationList = new ArrayList<TechTalk>();

            // Loop to get possible combination.
            while (startPoint != techTalkListSize) {
                int currentCount = startPoint;
                startPoint++;
                TechTalk currentTalk = talksListForOperation.get(currentCount);
                if (currentTalk.isScheduled())
                    continue;
                int talkTime = currentTalk.getTimeDuration();
                 if (talkTime > maxSessionTimeLimit
                        || talkTime + totalTime > maxSessionTimeLimit) {
                    continue;
                }

                possibleCombinationList.add(currentTalk);
                totalTime += talkTime;

                // If total time is completed for this session than break 
                if (morningSession) {
                    if (totalTime == maxSessionTimeLimit)
                        break;
                } else if (totalTime >= minSessionTimeLimit)
                    break;
            }

            boolean validSession = false;
            if (morningSession)
                validSession = (totalTime == maxSessionTimeLimit);
            else
                validSession = (totalTime >= minSessionTimeLimit && totalTime <= maxSessionTimeLimit);

            // If session is valid than add this session in the possible
            // combination list and set all added techTalk as scheduled.
            if (validSession) {
                possibleCombinationsOfTalks.add(possibleCombinationList);
                for (TechTalk techTalk : possibleCombinationList) {
                    techTalk.setScheduled(true);
                }
                possibleCombinationCount++;
                if (possibleCombinationCount == totalPossibleDays)
                    break;
            }
        }
        return possibleCombinationsOfTalks;
    }

    private List<List<TechTalk>> getScheduledTalksList(
            List<List<TechTalk>> combForMornSessions,
            List<List<TechTalk>> combForEveSessions) {
        List<List<TechTalk>> scheduledTalksList = new ArrayList<List<TechTalk>>();
        int totalPossibleDays = combForMornSessions.size();
        // for loop to schedule event for all possible days.
        for (int dayCount = 0; dayCount < totalPossibleDays; dayCount++) {
            List<TechTalk> techTalkList = new ArrayList<TechTalk>();
            // Create a date and initialize start time 09:00 AM.
            Date date = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mma ");
            date.setHours(9);
            date.setMinutes(0);
            date.setSeconds(0);
            int trackCount = dayCount + 1;
            String scheduledTime = dateFormat.format(date);
            System.out.println("Track " + trackCount + ":");
            // Morning Session 
            List<TechTalk> mornSessionTalkList = combForMornSessions.get(dayCount);
            for (TechTalk techTalk : mornSessionTalkList) {
                techTalk.setScheduledTime(scheduledTime);
                System.out.println(scheduledTime + techTalk.getTitle());
                scheduledTime = getNextScheduledTime(date,
                        techTalk.getTimeDuration());
                techTalkList.add(techTalk);
            }
            // Scheduled Lunch Time for 60 mins.
            int lunchTimeDuration = 60;
            TechTalk lunchTalk = new TechTalk("Lunch", "Lunch", 60);
            lunchTalk.setScheduledTime(scheduledTime);
            techTalkList.add(lunchTalk);
            System.out.println(scheduledTime + "Lunch");
            // Evening Session 
            scheduledTime = getNextScheduledTime(date, lunchTimeDuration);
            List<TechTalk> eveSessionTalkList = combForEveSessions.get(dayCount);
            for (TechTalk techTalk : eveSessionTalkList) {
                techTalk.setScheduledTime(scheduledTime);
                techTalkList.add(techTalk);
                System.out.println(scheduledTime + techTalk.getTitle());
                scheduledTime = getNextScheduledTime(date,
                        techTalk.getTimeDuration());
            }
            // Scheduled Networking Event at the end of session
            TechTalk networkingTalk = new TechTalk("Networking Event",
                    "Networking Event", 60);
            networkingTalk.setScheduledTime(scheduledTime);
            techTalkList.add(networkingTalk);
            System.out.println(scheduledTime + "Networking Event\n");
            scheduledTalksList.add(techTalkList);
        }
        return scheduledTalksList;
    }

    public static int getTotalTalksTime(List<TechTalk> talksList) {
        if (talksList == null || talksList.isEmpty()){
            return 0;
        }
        int totalTime = 0;
        for (TechTalk techTalk : talksList) {
            totalTime += techTalk.timeDuration;
        }
        return totalTime;
    }

    private String getNextScheduledTime(Date date, int timeDuration) {
        long timeInLong = date.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mma ");
        long timeDurationInLong = timeDuration * 60 * 1000;
        long newTimeInLong = timeInLong + timeDurationInLong;
        date.setTime(newTimeInLong);
        String str = dateFormat.format(date);
        return str;
    }

    public static void main(String[] args) {
        //point the path of test file here!!!
        String fileName = "<DriveName>:\\<TestFolder>\\<fileName>.txt";
        //My test file
        //String fileName = "C:\\ThoughtWorks\\Test.txt";
        ConferenceTrackManager conferenceManager = new ConferenceTrackManager();
        try {
            conferenceManager.scheduleConference(fileName);
        } catch (InvalidTechTalkException invalidTechTalk) {
            invalidTechTalk.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
