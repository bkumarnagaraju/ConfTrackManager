package com.thoughtWorks.conferenceTrackManagement;

/**
 * Conference Manager
 * @author Bharath
 *
 */
@SuppressWarnings("serial")
public class InvalidTechTalkException extends Exception{

    public InvalidTechTalkException(String msg) {
        super(msg);
    }

}
