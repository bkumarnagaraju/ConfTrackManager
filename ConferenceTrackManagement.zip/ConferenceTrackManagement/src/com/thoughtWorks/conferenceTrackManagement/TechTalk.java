package com.thoughtWorks.conferenceTrackManagement;
/**
 * Conference Manager
 * @author Bharath
 *
 */
public  class TechTalk implements Comparable {
    String title;
    String name;
    int timeDuration;
    boolean scheduled = false;
    String scheduledTime;


    public TechTalk(String title, String name, int time) {
        this.title = title;
        this.name = name;
        this.timeDuration = time;
    }


    public void setScheduled(boolean scheduled) {
        this.scheduled = scheduled;
    }


    public boolean isScheduled() {
        return scheduled;
    }


    public void setScheduledTime(String scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public String getScheduledTime() {
        return scheduledTime;
    }

    public int getTimeDuration() {
        return timeDuration;
    }

    public String getTitle() {
        return title;
    }


    @Override
    public int compareTo(Object obj) {
        TechTalk talk = (TechTalk) obj;
        if (this.timeDuration > talk.timeDuration)
            return -1;
        else if (this.timeDuration < talk.timeDuration)
            return 1;
        else
            return 0;
    }
}
